<?php
/**
 * Default Lexicon Entries for emo
 *
 * @package emo
 * @subpackage lexicon
 */

$_lang['emo'] = 'emo';
$_lang['emo.no_script_message'] = 'Activer Javascript!';
