# emo

emo is an email obfuscation plugin for MODX Revolution.

### Requirements

* MODX Revolution 2.2.4+
* PHP v5.3+

### Features

* Replace all plaintext emails and email links with span elements.
* Encrypt the email addresses and store them in javascript variables.
* Decrypt the email adresses by the browser on 'window.onload'.
